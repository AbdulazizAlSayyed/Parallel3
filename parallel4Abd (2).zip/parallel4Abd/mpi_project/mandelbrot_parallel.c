#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <math.h>

void compute_mandelbrot(int width, int height, int max_iterations, int is_parallel) {
    int pixels[height][width];

    if (is_parallel) {
        omp_set_num_threads(4);

        #pragma omp parallel for schedule(dynamic, 1)
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int iteration = 0;
                double zx = 0.0, zy = 0.0;
                double cx = (x - width / 2.0) * 4.0 / width;
                double cy = (y - height / 2.0) * 4.0 / height;

                while (zx * zx + zy * zy < 4.0 && iteration < max_iterations) {
                    double temp = zx * zx - zy * zy + cx;
                    zy = 2.0 * zx * zy + cy;
                    zx = temp;
                    iteration++;
                }
                pixels[y][x] = iteration;
            }
        }
    } else {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int iteration = 0;
                double zx = 0.0, zy = 0.0;
                double cx = (x - width / 2.0) * 4.0 / width;
                double cy = (y - height / 2.0) * 4.0 / height;

                while (zx * zx + zy * zy < 4.0 && iteration < max_iterations) {
                    double temp = zx * zx - zy * zy + cx;
                    zy = 2.0 * zx * zy + cy;
                    zx = temp;
                    iteration++;
                }
                pixels[y][x] = iteration;
            }
        }
    }

    // No print for Mandelbrot set values 
}

int main() {
    int width = 500;            
    int height = 500;           
    int max_iterations = 1000;  
    int num_threads = 4;        
    
    printf("Starting Mandelbrot computation...\n");

    //  sequential execution
    double start_time = omp_get_wtime();
    compute_mandelbrot(width, height, max_iterations, 0); // 0 means sequential
    double sequential_time = omp_get_wtime() - start_time;
    printf("Completed sequential computation...\n");

    //  parallel execution
    start_time = omp_get_wtime();
    compute_mandelbrot(width, height, max_iterations, 1); // 1 means parallel
    double parallel_time = omp_get_wtime() - start_time;
    printf("Completed parallel computation...\n");

    //  speedup and efficiency
    double speedup = sequential_time / parallel_time;
    double efficiency = (speedup / num_threads) * 100;

    printf("\n######### Sequential Results #########\n");
    printf("The time took to complete the operation is: %f seconds\n", sequential_time);

    printf("\n######### Parallel Results #########\n");
    printf("The time took to complete the operation is: %f seconds\n", parallel_time);

    printf("\nThe speedup factor is %f\n", speedup);
    printf("The efficiency is %f%%\n", efficiency);

    return 0;
}
