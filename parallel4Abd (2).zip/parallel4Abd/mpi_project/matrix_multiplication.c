#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void transpose_matrix(int *B, int *B_T, int K, int N) {
    #pragma omp parallel for
    for (int i = 0; i < K; i++) {
        for (int j = 0; j < N; j++) {
            B_T[j * K + i] = B[i * N + j];
        }
    }
}

void matrix_multiply_original(int *A, int *B, int *C, int M, int K, int N) {
    #pragma omp parallel for
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < K; k++) {
                sum += A[i * K + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matrix_multiply_transposed(int *A, int *B_T, int *C, int M, int K, int N) {
    #pragma omp parallel for
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < K; k++) {
                sum += A[i * K + k] * B_T[j * K + k];
            }
            C[i * N + j] = sum;
        }
    }
}

int main() {
    int M = 1000, K = 1000, N = 1000; 
    int *A = (int*) malloc(M * K * sizeof(int));
    int *B = (int*) malloc(K * N * sizeof(int));
    int *B_T = (int*) malloc(K * N * sizeof(int)); 
    int *C = (int*) malloc(M * N * sizeof(int));

    for (int i = 0; i < M * K; i++) A[i] = rand() % 100;
    for (int i = 0; i < K * N; i++) B[i] = rand() % 100;

    double start = omp_get_wtime();
    matrix_multiply_original(A, B, C, M, K, N);
    double end = omp_get_wtime();
    printf("Original multiplication time: %f seconds\n", end - start);

    start = omp_get_wtime();
    transpose_matrix(B, B_T, K, N);
    matrix_multiply_transposed(A, B_T, C, M, K, N);
    end = omp_get_wtime();
    printf("Transposed multiplication time: %f seconds\n", end - start);

    free(A);
    free(B);
    free(B_T);
    free(C);

    return 0;
}
